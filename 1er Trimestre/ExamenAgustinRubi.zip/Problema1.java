class Problema1 {
    public String cambiarString(String s) {
        String aux;
        String[] letras = new String[s.length];

        for (int i = 0; i < String.length; i++) {
            letras[i] = s.charAt(i);
        }

        for (int j = 0; j< letras.length; j++) {
            if (letras[j] == letras[j].toUpperCase()) { //Significa que la letra esta en mayuscula
                aux += letras[j].toLowerCase();
            } 
            if (letras[j] == letras[j].toLowerCase()) {
                aux += letras[j].toUpperCase();
            }
            else {
                aux += letras[j];
            }
        }
        return aux;
    }
}