class Problema3{
    public static void main (String[] args) {
        System.out.println("Introduce el valor de a y b");

        int a = Integer.parseInt(System.console().readLine());
        int b = Integer.parseInt(System.console().readLine());
        int[][] miArray = new int[a][b];
    }

    public void inizializarRayas(int[][] array) {
        boolean rayas = true;
        for (int i = 0; i < array.length; i++) {
            if (i % 2 == 0) {
                rayas = true;
            }
            else {
                rayas = false;
            }
            for (int j = 0; j < array[i].length; j++) {
                if (rayas) {
                    array[i][j] = 0;
                }
                else {
                    array[i][j] = 1;
                }
            }
        }
    }

    public void inizializarCuadrado(int[][] array) {
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                if(i == 0) {
                    array[i][j] = 1;
                }
                if(j == 0) {
                    array[i][j] = 1;
                }
                if(j == array[i][j].length) {
                    array[i][j] = 1;
                }
                if(i == array[i].length) {
                    array[i][j] = 1;
                }

            }
        }
    }

    public void inizializarAlterno(int[][] array){
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                array[0][0] = 0;  // Le damos 0 a el primer valor

                if(array[i][j-1] == 0) {  // Si el valor anterior valia 0, este vale 1.
                    array[i][j] = 1;
                } 
                else {
                    array[i][j] = 0; // Sino, vale 0
                }
            }
        }
    }

    public void inizializarEspiral(int[][] array) {
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                
            }
        }
    }
}