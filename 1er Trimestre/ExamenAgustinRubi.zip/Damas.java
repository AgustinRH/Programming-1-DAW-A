public class Damas {
    private char[] tablero = new char[64];
    private char contenido;
    // ....


    // Ejercicio A
    public int getContenido(int fila, int columna) {
        int pos = -1;

        // Si la fila es 0 extrae el valor de los primeros 8 posiciones.
        if(fila == 0) {
            contenido = tablero(columna);
        }

        // Si la fila es mayor a 0, al ser array dimensional se obtiene la posicion por donde empieza y se le suman las columnas para obtener el valor.
        if(fila > 0){
            pos = fila * 8 + columna;
            contenido = tablero(pos);
        }

        return contenido;
    }

    // Ejercicio B
    public void mostrarTablero() {
        int valor = 0;
        for(int i = 1; i >= tablero.length;i++) {
            valor = i;

            if(valor % 8 == 0) {  // Si el resto de valor entre 8 es cero cambia de linea...
            System.out.print(tablero[i]);
            System.out.println();
            } else {
                System.out.print(tablero[i]);
            }
        }
    }

}